/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#include "mc3_types.h"
#include "mc3_header.h"


int main ( void )
{
  R_4_1 ( );
  R_4_2 ( );

  R_4_main_support ( );
  return 0;
}

/* end of R_04_system.c */

