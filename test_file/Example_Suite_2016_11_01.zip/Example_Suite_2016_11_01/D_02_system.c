/*
 * Release: 2016-11-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#include "mc3_types.h"
#include "mc3_header.h"


int main ( void )
{
  D_2_main_support ( );
  return 0;
}

/* end of D_02_system.c */

