/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#ifndef R_13_01_
#define R_13_01_


#include "mc3_types.h"
#include "mc3_header.h"

extern volatile uint16_t vol;

extern void use_arr ( uint16_t a[ 2 ] );

extern void R_13_1_2 ( void );



#endif /* R_13_01_ */

