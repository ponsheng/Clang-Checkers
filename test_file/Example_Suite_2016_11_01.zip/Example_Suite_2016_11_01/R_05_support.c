/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_5_main_support ( void )
{
  R_5_1 ( );
  R_5_2 ( );
  R_5_3 ( );
  R_5_4 ( );
  R_5_5 ( );
  R_5_6 ( );
  R_5_7 ( );
  R_5_8 ( );
  R_5_9 ( );
}

/* end of R_05_support.c */

