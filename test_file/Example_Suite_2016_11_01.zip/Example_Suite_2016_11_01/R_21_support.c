/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_21_main_support ( void )
{
  R_21_1 ( );
  R_21_2 ( );
  R_21_3 ( );
  R_21_4 ( );
  R_21_5 ( );
  R_21_6 ( );
  R_21_7 ( );
  R_21_8 ( );
  R_21_9 ( );
  R_21_10 ( );
  R_21_11 ( );
  R_21_12 ( );
  R_21_13 ( );
  R_21_14 ( );
  R_21_15 ( );
  R_21_16 ( );
  R_21_17 ( );
  R_21_18 ( );
  R_21_19 ( );
  R_21_20 ( );
}

/* end of R_21_support.c */

