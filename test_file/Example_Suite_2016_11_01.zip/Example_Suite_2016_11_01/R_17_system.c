/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#include "mc3_types.h"
#include "mc3_header.h"


int main ( void )
{
  R_17_1 ( );
  R_17_2 ( );
  R_17_3 ( );
  R_17_4 ( );
  R_17_5 ( );
  R_17_6 ( );
  R_17_7 ( );
  R_17_8 ( );

  R_17_main_support ( );
  return 0;
}

/* end of R_17_system.c */

