/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_18_main_support ( void )
{
  R_18_1 ( );
  R_18_2 ( );
  R_18_3 ( );
  R_18_4 ( );
  R_18_5 ( );
  R_18_6 ( );
  R_18_7 ( );
  R_18_8 ( );
}

/* end of R_18_support.c */

