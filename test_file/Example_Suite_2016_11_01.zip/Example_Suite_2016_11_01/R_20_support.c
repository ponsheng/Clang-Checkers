/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_20_main_support ( void )
{
  R_20_1 ( );
  R_20_2 ( );
  R_20_3 ( );
  R_20_4 ( );
  R_20_5 ( );
  R_20_6 ( );
  R_20_7 ( );
  R_20_8 ( );
  R_20_9 ( );
  R_20_10 ( );
  R_20_11 ( );
  R_20_12 ( );
  R_20_13 ( );
  R_20_14 ( );
}

/* end of R_20_support.c */

