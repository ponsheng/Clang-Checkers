/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#ifndef R_22_06_
#define R_22_06_

#include "mc3_types.h"
#include "mc3_header.h"

extern void error_action ( void );


#endif /* R_22_06_ */
