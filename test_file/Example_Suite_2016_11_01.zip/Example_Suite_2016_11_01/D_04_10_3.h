/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/*
 * D.4.10
 *
 * Precautions shall be taken in order to prevent the contents of a header file 
 * being included more than once
 */

#ifndef D_4_10_3_H_

/* Non-compliant - does not #define D_4_10_3_H_ */

#endif /* D_4_10_3_H_ */
